﻿using System.Diagnostics;

namespace semana14_2
{
    class semana14
    {
        int[] datos = new int[12];
        public double suma = 0;
        bool salir = true;

        static void Main()
        {
            semana14 Main = new semana14();
            Main.Menu();
            Main.Opciones();

        }

        public void Menu()
        {

            Console.WriteLine("Ingrese 12 números");

            for (int i = 0; i < datos.GetLength(0); i++)
            {
                datos[i] = Convert.ToInt32(Console.ReadLine());
            }

        }

        public void Opciones()
        {
            do
            {
                Console.WriteLine("Selecciones una opcion");
                Console.WriteLine($"1. Mostrar la suma de los números de los arreglos \n 2. Mostrar los promedios de los números \n 3. Ordenar de menor a mayor \n 4. Ordenar de mayor a menor \n 5. Aumentar tamaño \n 6. Uso del metodo split \n 7.Salir");
                char Op = Console.ReadLine()[0];


                switch (Op)
                {
                    case '1':
                        Case1();
                        break;

                    case '2':
                        Case1();
                        Case2();
                        break;

                    case '3':
                        Case3();
                        break;

                    case '4':
                        Case4();
                        break;

                    case '5':
                        Case5();
                        break;

                    case '6':
                        Case6();
                        break;

                    case '7':
                        salir = false;
                        Console.WriteLine("Gracias por utilizar el código");
                        break;

                    default:
                        Console.WriteLine("La opción no existe");
                        break;

                }

            } while (salir);
        }

        public void Case1()
        {
            for (int j = 0; j < datos.GetLength(0); j++)
            {
                suma = suma + datos[j];
            }
            Console.WriteLine($"La suma de los datos es: {suma}");
        }

        public void Case2()
        {

            double promedio = suma / datos.Length;
            Console.WriteLine($"El promedio de los números es: {promedio}");
        }

        public void Case3()
        {
            Array.Reverse(datos);
            foreach (var datos in datos)
            {
                Console.WriteLine($"{datos}");
            }
        }
        public void Case4()
        {
            Array.Sort(datos);
            foreach (var datos in datos)
            {
                Console.WriteLine($"{datos}");
            }
        }
        public void Case5()
        {
            Console.WriteLine("");
            Array.Resize(ref datos, datos.Length + 2);
            Console.WriteLine($"Nuevo Tamaño: {datos.Length}");
            Console.WriteLine("Ingrese dos número más");
            datos[datos.Length - 2] = Convert.ToInt32(Console.ReadLine());
            datos[datos.Length - 1] = Convert.ToInt32(Console.ReadLine());

            foreach (var data in datos)
            {
                Console.WriteLine($"{data}");
            }
        }
        public void Case6()
        {
            Console.WriteLine("Usaremos la función split, por favor ingrese un texto que desee enlistar");
            string result = String.Join(",", datos);
            string[] text = new string[datos.Length];
            for (int i = 0; i < datos.Length; i++)
            {
                text[i] = datos[i].ToString();
            }
            text = result.Split(',');
            foreach (string item in text)
            {
                Console.WriteLine(item);
            }
        }
    }
}