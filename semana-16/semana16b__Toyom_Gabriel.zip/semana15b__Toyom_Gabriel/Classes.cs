using Classes;
var account = new BankAccounts("", 1000, "");
Console.WriteLine("Ingrese su nombre");
account.Owner = Console.ReadLine();
Console.WriteLine("Ingrese su tipo de cuenta, puede ser monetaria o ahorrativa");
account.type = Console.ReadLine().ToLower();
if (account.type == "monetaria" || account.type == "ahorrativa")
{
    string[] guardado = [account.Number, account.Owner, account.type];

Console.WriteLine("\nColoque la cantidad que desea retirar");
account.amount = Convert.ToDecimal(Console.ReadLine());
account.MakeWithdrawal(account.amount, DateTime.Now, "Rent payment");
Console.WriteLine(account.Balance);
Console.WriteLine("\nColoque la cantidad que desea depositar");
account.amount = Convert.ToDecimal(Console.ReadLine());
account.MakeDeposit(account.amount, DateTime.Now, "friend paid me back");
Console.WriteLine(account.Balance);

Console.WriteLine(account.GetAccountHistory());

Boolean salir = false;
Console.WriteLine("Menú");
do
{
    
    Console.WriteLine("Selecciones una opcion\na. Mostrar datos de cuenta\nb.Salir");
    char op = Console.ReadLine().ToLower()[0];

    switch (op)
    {
        case 'a':
            decimal[] guardado2 =[account.Balance];
            foreach (var item in guardado)
            {
                Console.WriteLine($"{item}");
            }

            foreach (var item2 in guardado2)
            {
                Console.WriteLine($"{item2}");
            }
            break;
        case 'b':
            salir = true;
            break;

        default:
            Console.WriteLine("No existe opción valida");
            salir = true;
            break;
    }
} while (!salir);
}
else
{
    Console.WriteLine("No es posible asignar el tipo de cuenta");
}

#region ERRORES
// Test that the initial balances must be positive:
try
{
    var invalidAccount = new BankAccounts("invalid", -100, "Monetay"); /*Cambio de valor*/
}
catch (ArgumentOutOfRangeException e)
{
    Console.WriteLine("Exception caught creating account with negative balance");
    Console.WriteLine(e.ToString());
}

// Test for a negative balance
try
{
    account.MakeWithdrawal(1760, DateTime.Now, "Attempt to overdraw"); /*Cambio de valor*/
}
catch (InvalidOperationException e)
{
    Console.WriteLine("Exception caught trying to overdraw");
    Console.WriteLine(e.ToString());
}

// Test for a more amount in front of the balance
try
{
    var invalidAccount = new BankAccounts("invalid", 2000, "Monetay"); /*Cambio de valor*/
    account.MakeWithdrawal(2060, DateTime.Now, "Attempt to not founds");
}
catch (InvalidOperationException e)
{
    Console.WriteLine("Exception caught trying to not founds");
    Console.WriteLine(e.ToString());
}

// Test that the initial balances must be positive:
try
{
    var invalidAccount = new BankAccounts("invalid", 100-200-100, "Monetay"); /*Cambio de valor*/
}
catch (ArgumentOutOfRangeException e)
{
    Console.WriteLine("Exception caught creating account with negative balance");
    Console.WriteLine(e.ToString());
}

#endregion