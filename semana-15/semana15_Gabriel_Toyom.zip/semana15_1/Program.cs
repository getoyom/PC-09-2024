﻿namespace semana15
{
    class Toyom
    {
        int numero;
        string cadena;
        int r3;
        bool Salir = false;

        public static void Main()
        {
            Toyom objetoProgram = new Toyom(0, " ", 0);
            objetoProgram.menu();
        }

        public Toyom(int numero, string cadena, int r3)
        {
            this.numero = numero;
            this.cadena = cadena;
            this.r3 = r3;
        }
        void show()
        {
            Console.WriteLine(this.numero);
            Console.WriteLine(this.cadena);
            Console.WriteLine(this.r3);
        }

        public void menu()
        {
            do
            {
                Console.WriteLine("Menú");
                Console.WriteLine("Seleccione una opcion");
                Console.WriteLine("a.Ingresar valores");
                Console.WriteLine("b.Mostrar valores");
                Console.WriteLine("c.Salir del programa");
                char menu = Console.ReadLine().ToLower()[0];
                Toyom objetoProgram = new Toyom(numero, cadena, r3);
                switch (menu)
                {
                    case 'a':
                        Console.WriteLine("Ingrese tres valores, el primero y terceron debe ser un número entero mientras que el segudo algun texto");
                        numero = Convert.ToInt32(Console.ReadLine());
                        cadena = Console.ReadLine();
                        r3 = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 'b':
                        objetoProgram.show();
                        break;
                    case 'c':
                        Salir = true;
                        break;
                    default:
                        Console.WriteLine("Opción invalida, seleccione una valida");
                        break;
                }
            } while (!Salir);
        }
    }
}