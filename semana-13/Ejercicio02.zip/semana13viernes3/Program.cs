﻿class semana13viernes3
{
    /*Realizado por Diego Aguilar 10444024  y Gabriel Toyom 1051524*/
    static void Main()
    {
        semana13viernes3 datos = new semana13viernes3();
        datos.datos();

    }

    public void datos()
    {
            string[] nombres = new string[4];
            string[] apellidos = new string[4];
            int[] edades = new int[4];
            string[] telefonos = new string[4];

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Ingresa los datos para el cliente {i + 1}:");

                Console.Write("Nombre: ");
                nombres[i] = Console.ReadLine();

                Console.Write("Apellido: ");
                apellidos[i] = Console.ReadLine();

                Console.Write("Edad: ");
                edades[i] = Int32.Parse(Console.ReadLine());

                Console.Write("Teléfono: ");
                telefonos[i] = Console.ReadLine();
            }

            Console.WriteLine("Datos de los clientes:");

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Cliente {i + 1}:");
                Console.WriteLine($"Nombre: {nombres[i]}");
                Console.WriteLine($"Apellido: {apellidos[i]}");
                Console.WriteLine($"Edad: {edades[i]}");
                Console.WriteLine($"Teléfono: {telefonos[i]}");
                  
            }   
    }
}
