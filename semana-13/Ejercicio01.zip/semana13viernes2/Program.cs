﻿using System;

namespace semana13viernes2
{
    public class semana13Arreglos
    {
        /*Realizado por Diego Aguilar 10444024  y Gabriel Toyom 1051524*/
        static void Main()
        {
            semana13Arreglos arreglos = new semana13Arreglos();
            arreglos.mostrar();


        }

        public void mostrar()
        {
            Console.WriteLine("Ingrese 8 números");
            int[] n = new int[8]; 
            int sum = 0;
            int promedio = sum/8;
            for (int i = 0; i < 8; i++)
            {
                Console.Write($"Ingrese valor para posición {i+1}: ");
                String linea = Console.ReadLine();
                n[i] = Convert.ToInt32(linea);

                sum = sum + n[i];
                
            }
            
            foreach (int num in n)
            {
                Console.WriteLine($"{num}");
            }
            Console.WriteLine($"La suma de los números es {sum}");
            Console.WriteLine($"El promedio es {promedio}");
        }
    }

    

}
